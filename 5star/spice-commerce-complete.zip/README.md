# Spice & Dry Fruits Commerce Platform

An API-first commerce platform for an Indian spice and dry-fruit retailer.
PHP 8.3, MySQL 8 (or MariaDB 10.4+), no framework, no third-party runtime
dependencies.

---

## What is in this archive

| | |
|---|---|
| `backend/` | The API. 198 PHP files, 218 routes, 76 tables. |
| `web/` | Customer storefront and staff console. Bootstrap 5, ES modules, no build step. |
| `database/` | 11 migrations, 11 rollbacks, 9 seeds, and a single-file import. |
| `docs/` | OpenAPI 3 specification and client integration notes. |
| `GO_LIVE.md` | What must be true before real customers arrive. |
| `TESTING.md` | Every suite, and every bug found while writing them. |

---

## Installing

### On a server you control

```bash
cd backend
php bin/setup.php        # creates .env, generates secrets, checks the install
php bin/migrate.php
php bin/seed_admin.php
```

Serve `backend/public`. Check `/api/v1/health` returns `{"success":true,...}`.

Then point `web/assets/js/config.js` and `web/admin/assets/config.js` at that
address and serve `web/`.

### On shared hosting (Hostinger, cPanel)

Create an empty utf8mb4 database and import
`database/spice_commerce_full.sql` through phpMyAdmin. Then run
`php bin/setup.php` and `php bin/seed_admin.php`.

That file omits five CHECK constraints that MariaDB refuses. See TESTING.md.

---

## Verified state

Every figure below comes from a run against an empty database, not an estimate.

| Suite | Assertions |
|---|---|
| `bin/test_pricing.php` | 76 |
| `bin/test_promotions.php` | 47 |
| `bin/test_bogo.php` | 35 |
| `bin/test_orders.php` | 56 |
| `bin/test_notifications.php` | 39 |
| `bin/test_openapi.php` | 32 |
| `bin/smoke_test.php` | 21 |
| `bin/smoke_test_catalog.php` | 54 |
| `bin/smoke_test_cart.php` | 83 |
| `bin/smoke_test_promotions.php` | 94 |
| `bin/smoke_test_checkout.php` | 92 |
| `bin/smoke_test_delivery.php` | 70 |
| `bin/test_concurrency.php` | 34 (under real Apache, parallel requests) |
| `web/test/test_storefront.mjs` | 101 |
| `web/test/test_console.mjs` | 64 |

**898 assertions, 0 failures.** `bin/audit_consistency.php` reports 0 errors.

---

## Business rules, and where they live

| | | |
|---|---|---|
| BR-001 | No inventory | No stock column exists anywhere |
| BR-003 | OTP before confirmation | `CheckoutService::verifyOtp` |
| BR-004 | Prepaid UPI only | `PaymentGatewayInterface`; no COD path |
| BR-005 | No progress without payment | `OrderService::assertPaid` |
| BR-006 | Calculated delivery | `DeliveryChargeService` |
| BR-007 | Automatic courier choice | `CourierSelector`, scored on weight, pincode, cost, SLA |
| BR-008 | Full order timeline | `order_timeline`, append-only |
| BR-009 | Everything logged | `ActivityLogMiddleware` |

---

## Decisions worth knowing before you change anything

**Money is integer paise.** Every amount passes through `App\Helpers\Money`.
Floating point loses rupees at scale, and a shop that is out by ₹0.01 per order
is out by real money by the end of a year.

**Indian MRP is GST-inclusive, so tax is extracted, not added.** One
`PricingEngine` produces every total in the system. Nothing else computes a
price.

**Wallet credit is a tender, not a discount.** It reduces `amount_payable` and
never touches `grand_total` or `tax_total`, which keeps the GST treatment
correct.

**Buy-X-get-Y is expressed as a discount, not a free line.** A zero-priced line
has no taxable value, so the tax on what was actually paid for would be computed
against the wrong base.

**The wallet ledger is append-only**, enforced by database triggers rather than
by convention.

**Guests get real carts**, merged into the account on sign-in.

---

## Not done, and honest about it

- **Flutter apps.** Zero lines. The OpenAPI spec and `docs/CLIENT_INTEGRATION.md`
  are what a mobile developer needs to start.
- **No payment, SMS or courier call has ever run against a real provider.** Every
  test used sandbox drivers that always succeed. This is the largest remaining
  unknown; see GO_LIVE.md.
- **Browser rendering is unverified.** All web tests run in jsdom, which cannot
  see layout, Bootstrap's own JavaScript, or a phone.
- **Load is untested.** Concurrency correctness is proven; throughput on your
  hardware is not.
- **Bulk promotional messaging** and **WhatsApp order updates** are not built.
- **The four policy pages are placeholders** and must be reviewed by someone
  qualified.

Run `php bin/preflight.php` before going live. It refuses to pass while anything
is still configured for development.
