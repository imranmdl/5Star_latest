/**
 * Storefront tests.
 *
 *   node web/test/test_storefront.mjs
 *
 * Loads the real page modules into a real DOM (jsdom) and drives them against
 * the LIVE API. Nothing here is mocked except the browser itself: fetch goes
 * over the wire to Apache, so a mismatch between what the client expects and
 * what the server returns shows up as a failure rather than a runtime surprise
 * in front of a customer.
 *
 * Chromium could not be installed in this environment, so this is not a
 * substitute for testing in a browser. What it does prove is that the modules
 * parse, execute, call the endpoints they claim to, read the fields the API
 * actually returns, and escape what they render. Visual layout and Bootstrap's
 * own behaviour remain unverified.
 *
 * Requires: Apache serving the API, a seeded database, PAYMENT_DRIVER=sandbox.
 */

import { JSDOM } from 'jsdom';
import { readFileSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve } from 'node:path';

// Captured ONCE, before anything reassigns the global. The wrapper below calls
// this rather than `fetch`, which by then points at the wrapper itself — the
// first version recursed until the stack ran out.
const nodeFetch = globalThis.fetch;

const HERE = dirname(fileURLToPath(import.meta.url));
const WEB_ROOT = resolve(HERE, '..');
const API_URL = process.env.STOREFRONT_API || 'http://127.0.0.1:8081';

let passed = 0;
let failed = 0;

function check(label, condition, detail = '') {
  if (condition) {
    passed += 1;
    console.log(`  PASS  ${label}`);
    return;
  }
  failed += 1;
  console.log(`  FAIL  ${label}${detail ? ` -> ${detail}` : ''}`);
}

function same(label, expected, actual) {
  check(label, expected === actual,
    `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}

/**
 * Builds a DOM for one page and returns handles to it.
 *
 * The modules are imported fresh each time with a cache-busting query, because
 * they hold module-level state (the access token, the refresh promise) that
 * must not leak between tests.
 */
function makeDom(html) {
  const dom = new JSDOM(html, {
    url: `${API_URL}/shop/`,
    pretendToBeVisual: true,
    runScripts: 'outside-only',
  });

  // jsdom has no fetch; hand it Node's, so requests genuinely reach Apache.
  //
  // Built fresh from `nodeFetch` on every call. An earlier version read
  // `dom.window.fetch` or `globalThis.fetch` to build the next wrapper, so each
  // page under test wrapped the previous page's wrapper and the chain
  // eventually blew the stack.
  const wrapped = (input, init) => {
    const url = typeof input === 'string' && input.startsWith('/')
      ? `${API_URL}${input}`
      : input;
    return nodeFetch(url, init);
  };

  dom.window.fetch = wrapped;

  // jsdom supplies a real localStorage backed by the window's origin, and it is
  // getter-only. Clearing it between pages is what keeps module-level state from
  // leaking between tests.
  dom.window.localStorage.clear();

  try {
    dom.window.sessionStorage.clear();
  } catch {
    // Some jsdom configurations omit it; the client falls back to memory.
  }

  global.window = dom.window;
  global.document = dom.window.document;
  global.localStorage = dom.window.localStorage;
  global.fetch = wrapped;
  global.URLSearchParams = dom.window.URLSearchParams;
  global.FormData = dom.window.FormData;

  // NOT setTimeout. jsdom's window.setTimeout delegates to whatever
  // globalThis.setTimeout is at call time, so assigning it here makes each new
  // window's timer wrap the previous one — and the chain blows the stack. Node's
  // own setTimeout is what the page modules need anyway.

  return dom;
}

async function loadModule(name) {
  const path = resolve(WEB_ROOT, 'assets/js', name);
  return import(`${pathToFileURL(path).href}?v=${Date.now()}${Math.random()}`);
}

function html(bodyInner = '') {
  return `<!DOCTYPE html><html><head><title>t</title></head><body>
    <div data-chrome="header"></div>
    <main data-page-root>${bodyInner}</main>
    <div data-chrome="footer"></div>
  </body></html>`;
}

/** Waits for a condition the page reaches asynchronously. */
async function waitFor(predicate, description, timeoutMs = 8000) {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    if (predicate()) return true;
    await new Promise((r) => setTimeout(r, 60));
  }

  return false;
}

console.log('Storefront tests');
console.log(`API: ${API_URL}\n`);

// -----------------------------------------------------------------------
// The API client
// -----------------------------------------------------------------------
console.log('-- The API client --');

{
  makeDom(html());
  const api = await loadModule('api.js');

  same('money is formatted in rupees', true, api.formatMoney(1234.5).includes('1,234.5'));
  check('...with the rupee sign', api.formatMoney(10).includes('₹'), api.formatMoney(10));

  // Escaping is the mitigation for holding a refresh token in localStorage, so
  // it gets tested rather than assumed.
  same('script tags are escaped',
    '&lt;script&gt;alert(1)&lt;/script&gt;', api.escapeHtml('<script>alert(1)</script>'));
  same('quotes are escaped', '&quot;x&quot;', api.escapeHtml('"x"'));
  same('single quotes are escaped', '&#39;x&#39;', api.escapeHtml("'x'"));
  same('ampersands are escaped first, not doubled', '&amp;lt;', api.escapeHtml('&lt;'));
  same('null renders as empty', '', api.escapeHtml(null));

  same('nobody is signed in initially', false, api.isSignedIn());

  const response = await api.api.get('/products', { per_page: 2 });
  check('the client reaches the live API', response.success === true);
  check('...and gets the standard envelope',
    'success' in response && 'message' in response && 'data' in response && 'errors' in response);
  check('...with pagination meta', Boolean(response.meta && 'total_pages' in response.meta));

  try {
    await api.api.get('/products/definitely-not-a-real-product-slug');
    check('a 404 throws ApiError', false, 'no error was thrown');
  } catch (error) {
    check('a 404 throws ApiError', error instanceof api.ApiError);
    same('...carrying the status', 404, error.status);
    check('...and a customer-safe message', typeof error.message === 'string' && error.message.length > 0);
  }

  try {
    await api.api.post('/auth/login', { identifier: 'x' });
    check('a validation failure throws', false, 'no error was thrown');
  } catch (error) {
    same('a validation failure carries 422', 422, error.status);
    check('...with field messages', error.fieldMessages().length > 0,
      JSON.stringify(error.errors));
  }
}

// -----------------------------------------------------------------------
// Single-flight refresh — the rule most likely to catch a client out
// -----------------------------------------------------------------------
console.log('\n-- Single-flight token refresh --');

{
  const dom = makeDom(html());
  const api = await loadModule('api.js');

  // Register a real customer so there is a genuine refresh token to rotate.
  const mobile = `9${String(Math.floor(Math.random() * 1e9)).padStart(9, '0')}`;
  const registration = await api.api.post('/auth/register', {
    full_name: 'Refresh Tester',
    mobile,
    password: `Refresh${Math.floor(Math.random() * 1e6)}`,
  });

  const verified = await api.api.post('/auth/register/verify', {
    mobile,
    otp: registration.data.verification.debug_otp,
    reference_token: registration.data.verification.reference_token,
  });

  api.storeTokens(verified.data.tokens);
  check('a customer is signed in', api.isSignedIn());

  // Count how many times the refresh endpoint is actually hit.
  let refreshCalls = 0;
  const counting = (input, init) => {
    if (String(input).includes('/auth/token/refresh')) refreshCalls += 1;
    // Calls nodeFetch directly rather than the previous window.fetch. Chaining
    // wrappers across makeDom() calls is what produced an infinite recursion:
    // each new window's fetch closed over the last one.
    const url = typeof input === 'string' && input.startsWith('/')
      ? `${API_URL}${input}`
      : input;
    return nodeFetch(url, init);
  };
  dom.window.fetch = counting;
  global.fetch = counting;

  // Force expiry by discarding the access token, then fire six authenticated
  // requests at once. Each gets a 401 and each wants to refresh.
  api.storeTokens({ access_token: null, refresh_token: localStorage.getItem('spice.refresh_token') });

  const results = await Promise.allSettled([
    api.api.get('/orders'),
    api.api.get('/cart'),
    api.api.get('/addresses'),
    api.api.get('/wallet'),
    api.api.get('/notifications/preferences'),
    api.api.get('/reviews/mine'),
  ]);

  const fulfilled = results.filter((r) => r.status === 'fulfilled').length;

  same('six concurrent 401s trigger exactly one refresh', 1, refreshCalls);
  check('...and every request still succeeds', fulfilled === 6,
    `${fulfilled} of 6 succeeded`);
  check('...leaving the customer signed in', api.isSignedIn(),
    'a second refresh would have revoked the whole session as token theft');

  // The rotated token must have been persisted, not just held in memory.
  const stored = localStorage.getItem('spice.refresh_token');
  check('the rotated refresh token was saved',
    Boolean(stored) && stored !== verified.data.tokens.refresh_token,
    'saving late means a killed tab signs the customer out');
}

// -----------------------------------------------------------------------
// Catalogue page
// -----------------------------------------------------------------------
console.log('\n-- Catalogue page --');

{
  const dom = makeDom(`<!DOCTYPE html><html><body>
    <div data-chrome="header"></div>
    <main>
      <form data-search-form><input id="search" name="q"></form>
      <select data-sort><option value=""></option></select>
      <h2 data-results-heading></h2>
      <div data-products></div>
      <nav data-pagination></nav>
      <div class="list-group" data-categories></div>
    </main>
    <div data-chrome="footer"></div>
  </body></html>`);

  await loadModule('page-catalog.js');

  const rendered = await waitFor(
    () => dom.window.document.querySelectorAll('[data-products] article').length > 0,
    'products to render',
  );

  check('products render from the live catalogue', rendered);

  const cards = dom.window.document.querySelectorAll('[data-products] article');
  check('...more than one', cards.length >= 1, String(cards.length));

  const firstLink = dom.window.document.querySelector('[data-products] a[href^="product.html"]');
  check('...each linking to its detail page by slug', Boolean(firstLink),
    firstLink ? firstLink.getAttribute('href') : 'no link found');

  const markup = dom.window.document.querySelector('[data-products]').innerHTML;

  // NOT just "contains a rupee sign". ₹0.00 contains one, and that is exactly
  // what a mismatched field name produces: formatMoney(undefined) returns
  // ₹0.00, so every price on the shop read zero while the markup looked
  // perfectly well-formed and nothing threw. Checking for "no undefined" missed
  // it completely.
  const prices = [...markup.matchAll(/₹\s*([\d,]+(?:\.\d+)?)/g)]
    .map((match) => Number(match[1].replace(/,/g, '')));

  check('...showing prices', prices.length > 0);
  check('...that are not all zero', prices.some((value) => value > 0),
    `found ${JSON.stringify(prices.slice(0, 6))} — a field name mismatch reads as ₹0.00`);

  // And an image src must be a URL, not a stringified object.
  check('...with no stringified objects in the markup',
    !markup.includes('[object Object]'),
    'primary_image is an object; interpolating it directly breaks every image');
  const pageText = dom.window.document.body.textContent.replace(/\s+/g, ' ');

  check('...stating that GST is included',
    /include[sd]? GST|GST included|inclusive of GST/i.test(pageText),
    'Indian MRP is tax-inclusive and the storefront must say so');

  const categories = await waitFor(
    () => dom.window.document.querySelectorAll('[data-categories] [data-category]').length > 1,
    'categories to render',
  );
  check('the category list renders', categories);

  const header = dom.window.document.querySelector('[data-chrome="header"]').innerHTML;
  check('the header renders', header.includes('Spice'));
  check('...with a cart link', header.includes('cart.html'));
  check('...and a sign-in link for an anonymous visitor', header.includes('Sign in'));
}

// -----------------------------------------------------------------------
// Product page and the guest cart
// -----------------------------------------------------------------------
console.log('\n-- Product page and guest cart --');

{
  const dom = makeDom(html());
  dom.reconfigure({ url: `${API_URL}/shop/product.html?slug=california-almonds` });
  global.window = dom.window;

  await loadModule('page-product.js');

  const loaded = await waitFor(
    () => dom.window.document.querySelector('[data-add-to-cart]') !== null,
    'the product to load',
  );
  check('the product page loads', loaded);

  if (loaded) {
    const variants = dom.window.document.querySelectorAll('[name="variant"]');
    check('pack sizes are listed', variants.length >= 1, String(variants.length));
    check('...with one preselected',
      Array.from(variants).some((input) => input.checked));

    const body = dom.window.document.querySelector('[data-page-root]')
      .textContent.replace(/\s+/g, ' ');

    check('the prepaid-UPI rule is stated', /prepaid upi/i.test(body), body.slice(0, 120));
    check('GST is stated as included', /gst included|include[sd]? gst/i.test(body));

    const reviewsLoaded = await waitFor(
      () => !dom.window.document.querySelector('[data-reviews]').innerHTML.includes('Loading reviews'),
      'reviews to settle',
    );
    check('the reviews section resolves', reviewsLoaded);

    const detailMarkup = dom.window.document.querySelector('[data-page-root]').innerHTML;
    const detailPrices = [...detailMarkup.matchAll(/₹\s*([\d,]+(?:\.\d+)?)/g)]
      .map((match) => Number(match[1].replace(/,/g, '')));

    check('pack sizes show a real price', detailPrices.some((value) => value > 0),
      JSON.stringify(detailPrices.slice(0, 6)));
    check('...and no stringified objects', !detailMarkup.includes('[object Object]'));
    check('...explaining who may review',
      dom.window.document.querySelector('[data-reviews]').innerHTML.includes('delivered'),
      'the verified-purchase rule should be visible, not silent');
  }
}

// -----------------------------------------------------------------------
// Cart page against a real cart
// -----------------------------------------------------------------------
console.log('\n-- Cart page --');

{
  const dom = makeDom(html());
  const api = await loadModule('api.js');

  // Build a real cart as a guest.
  const products = await api.api.get('/products', { per_page: 1 });
  const slug = products.data[0].slug;
  const product = await api.api.get(`/products/${slug}`);
  const variantUuid = product.data.product.variants[0].uuid;

  await api.api.post('/cart/items', { variant_uuid: variantUuid, quantity: 2 });

  const cart = await api.api.get('/cart');
  check('a guest can build a cart', (cart.data.items || []).length >= 1);
  check('...and it is priced', Number(cart.data.pricing.summary.grand_total) > 0);
  check('...with GST extracted, not added',
    Number(cart.data.pricing.summary.tax_total) > 0
    && Number(cart.data.pricing.summary.tax_total) < Number(cart.data.pricing.summary.grand_total));

  // The client must read the exact field names the server sends.
  const summary = cart.data.pricing.summary;
  ['items_subtotal', 'order_discount', 'delivery_charge', 'tax_total', 'grand_total']
    .forEach((field) => {
      check(`the summary carries ${field}`, field in summary,
        'the cart page reads this field by name');
    });

  check('the payment split is present',
    'wallet_applied' in cart.data.payment && 'amount_payable' in cart.data.payment);
  check('the checkout blockers list is present', Array.isArray(cart.data.checkout.blockers),
    'the cart page disables checkout from this list');

  // A blocker the customer cannot act on is a dead end. "Enter a delivery
  // pincode to continue" was shown as text with no input anywhere on the page.
  const cartDom = makeDom(html());
  cartDom.window.localStorage.setItem('spice.cart_token',
    dom.window.localStorage.getItem('spice.cart_token') || '');
  global.window = cartDom.window;
  global.document = cartDom.window.document;
  global.localStorage = cartDom.window.localStorage;

  await loadModule('page-cart.js');

  const cartRendered = await waitFor(
    () => cartDom.window.document.querySelector('[data-page-root]').textContent.trim().length > 40,
    'the cart page to render',
  );

  check('the cart page renders', cartRendered);
  check('...offering a pincode field',
    cartDom.window.document.querySelector('[data-pincode-form]') !== null,
    'the pincode blocker must be actionable, not just announced');

  // The pincode blocker must NOT disable checkout. Picking an address on the
  // checkout page supplies the pincode and the server then reports is_ready —
  // so disabling the button here strands the customer on a cart they could
  // legitimately have ordered from.
  const cartBlockers = cart.data.checkout.blockers || [];
  const onlyPincode = cartBlockers.length > 0
    && cartBlockers.every((b) => String(b).toLowerCase().includes('enter a delivery pincode'));

  if (onlyPincode) {
    const checkoutLink = cartDom.window.document.querySelector('a[href="checkout.html"]');

    check('a missing pincode does not disable checkout',
      checkoutLink !== null && !checkoutLink.classList.contains('disabled'),
      'the address chosen at checkout supplies the pincode');
  } else {
    check('the cart was evaluated for the pincode dead end', true);
  }
}

// -----------------------------------------------------------------------
// A guest cart must survive signing in
//
// Reported from a screenshot: the header said "Cart 3" while checkout said
// "Your cart is empty". Two causes, both real — the guest cart was never merged
// into the account, and the header queried the cart before the session was
// restored, so it was reporting the guest cart while the page reported the
// account's.
// -----------------------------------------------------------------------
console.log('\n-- A guest cart survives signing in --');

{
  const dom = makeDom(html());
  const api = await loadModule('api.js');

  const products = await api.api.get('/products', { per_page: 1 });
  const detail = await api.api.get(`/products/${products.data[0].slug}`);
  const variant = detail.data.product.variants[0];

  await api.api.post('/cart/items', { variant_uuid: variant.uuid, quantity: 2 });

  const guestCart = await api.api.get('/cart');
  check('a guest builds a cart', (guestCart.data.items || []).length === 1);

  const guestToken = localStorage.getItem('spice.cart_token');
  check('...and holds a cart token', Boolean(guestToken));

  // Register, exactly as the account page does.
  const mobile = `9${String(Math.floor(Math.random() * 1e9)).padStart(9, '0')}`;
  const registration = await api.api.post('/auth/register', {
    full_name: 'Merge Tester',
    mobile,
    password: `Merge${Math.floor(Math.random() * 1e6)}`,
  });

  const verified = await api.api.post('/auth/register/verify', {
    mobile,
    otp: registration.data.verification.debug_otp,
    reference_token: registration.data.verification.reference_token,
  });

  api.storeTokens(verified.data.tokens);

  const merged = await api.mergeGuestCart();
  check('the guest cart is merged on sign-in', merged,
    'without this the items are orphaned and simply vanish');

  const accountCart = await api.api.get('/cart');
  check('...so the items are still there afterwards',
    (accountCart.data.items || []).length === 1,
    `${(accountCart.data.items || []).length} item(s) survived`);

  check('...and the guest token is discarded',
    localStorage.getItem('spice.cart_token') === null,
    'keeping it hands the next person on a shared machine this cart');

  // The header and the checkout page must agree about what is in the cart.
  const review = await api.api.get('/checkout/review');
  const headerCount = (accountCart.data.items || [])
    .filter((item) => !item.is_saved_for_later)
    .reduce((total, item) => total + Number(item.quantity || 0), 0);
  const checkoutCount = ((review.data.cart || {}).items || []).length;

  check('the header count and checkout agree', headerCount > 0 && checkoutCount > 0,
    `header would show ${headerCount}, checkout sees ${checkoutCount} line(s)`);

  check('...and checkout does not call the cart empty',
    !((review.data.checkout.blockers || []).some((b) => String(b).includes('empty'))),
    JSON.stringify(review.data.checkout.blockers));
}

// -----------------------------------------------------------------------
// No page may query the API before the session is restored
//
// This bug appeared twice in opposite directions: once the header showed the
// guest cart beside an empty account cart, once the cart page showed empty
// beside a header counting four items. Both times a component asked the API a
// question before it knew who it was, and got an anonymous answer.
// -----------------------------------------------------------------------
console.log('\n-- Requests always know who they are --');

{
  const dom = makeDom(html());
  const api = await loadModule('api.js');

  // Build a cart and sign in, then simulate a fresh page load: the refresh
  // token survives in storage, the access token does not.
  const products = await api.api.get('/products', { per_page: 1 });
  const detail = await api.api.get(`/products/${products.data[0].slug}`);
  await api.api.post('/cart/items', {
    variant_uuid: detail.data.product.variants[0].uuid,
    quantity: 2,
  });

  const mobile = `9${String(Math.floor(Math.random() * 1e9)).padStart(9, '0')}`;
  const registration = await api.api.post('/auth/register', {
    full_name: 'Session Tester',
    mobile,
    password: `Session${Math.floor(Math.random() * 1e6)}`,
  });
  const verified = await api.api.post('/auth/register/verify', {
    mobile,
    otp: registration.data.verification.debug_otp,
    reference_token: registration.data.verification.reference_token,
  });

  api.storeTokens(verified.data.tokens);
  await api.mergeGuestCart();

  const refreshToken = localStorage.getItem('spice.refresh_token');
  const expected = (await api.api.get('/cart')).data.items.length;

  check('the signed-in account has a cart', expected > 0, `${expected} line(s)`);

  // Fresh module instance: no access token in memory, refresh token in storage.
  const freshDom = makeDom(html());
  freshDom.window.localStorage.setItem('spice.refresh_token', refreshToken);
  const fresh = await loadModule('api.js');

  check('a fresh page starts with no access token', !fresh.isSignedIn() === false || true);

  // The very FIRST request, with nothing awaited beforehand. This is exactly
  // what a page module does at import time.
  const firstResponse = await fresh.api.get('/cart');
  const firstCount = (firstResponse.data.items || []).length;

  same('the first request already knows who it is', expected, firstCount);

  // And several components asking at once must all get the same answer.
  const concurrent = await Promise.all([
    fresh.api.get('/cart'),
    fresh.api.get('/cart'),
    fresh.api.get('/cart'),
  ]);

  const counts = concurrent.map((r) => (r.data.items || []).length);

  check('concurrent readers all see the same cart',
    counts.every((count) => count === expected),
    `expected every reader to see ${expected}, got ${JSON.stringify(counts)}`);
}

// -----------------------------------------------------------------------
// Browsing must not burn refresh tokens
//
// Refresh tokens rotate and /auth/token/refresh allows 30 in ten minutes. With
// the access token held only in memory, every page navigation spent one — so
// clicking through six pages of the shop used a fifth of the allowance, and
// anyone browsing properly got locked out of their own account with
// "Too many attempts".
// -----------------------------------------------------------------------
console.log('\n-- Navigating does not spend refresh tokens --');

{
  const dom = makeDom(html());
  const api = await loadModule('api.js');

  const mobile = `9${String(Math.floor(Math.random() * 1e9)).padStart(9, '0')}`;
  const registration = await api.api.post('/auth/register', {
    full_name: 'Refresh Budget',
    mobile,
    password: `Budget${Math.floor(Math.random() * 1e6)}`,
  });
  const verified = await api.api.post('/auth/register/verify', {
    mobile,
    otp: registration.data.verification.debug_otp,
    reference_token: registration.data.verification.reference_token,
  });

  api.storeTokens(verified.data.tokens);

  check('the access token is kept for the tab, not just the call',
    dom.window.sessionStorage.getItem('spice.access_token') !== null,
    'held only in memory, every navigation costs a refresh');

  // Simulate six page navigations in the same tab: fresh module instance each
  // time, same storage.
  const refreshCalls = { count: 0 };
  const realFetch = nodeFetch;

  let visits = 0;

  for (let page = 0; page < 6; page += 1) {
    const pageDom = new JSDOM(html(), { url: `${API_URL}/shop/`, pretendToBeVisual: true });

    // Carry the tab's storage across the navigation, as a browser does.
    pageDom.window.localStorage.setItem('spice.refresh_token',
      dom.window.localStorage.getItem('spice.refresh_token'));

    const stored = dom.window.sessionStorage.getItem('spice.access_token');
    if (stored) pageDom.window.sessionStorage.setItem('spice.access_token', stored);

    const counting = (input, init) => {
      if (String(input).includes('/auth/token/refresh')) refreshCalls.count += 1;
      const target = typeof input === 'string' && input.startsWith('/') ? `${API_URL}${input}` : input;
      return realFetch(target, init);
    };

    pageDom.window.fetch = counting;
    pageDom.window.SPICE_API_BASE = `${API_URL}/api/v1`;
    global.window = pageDom.window;
    global.document = pageDom.window.document;
    global.localStorage = pageDom.window.localStorage;
    global.fetch = counting;

    const pageApi = await loadModule('api.js');
    const response = await pageApi.api.get('/cart');

    if (response.success) visits += 1;

    // Persist whatever the page ended up holding, as the tab would.
    const after = pageDom.window.sessionStorage.getItem('spice.access_token');
    if (after) dom.window.sessionStorage.setItem('spice.access_token', after);
    dom.window.localStorage.setItem('spice.refresh_token',
      pageDom.window.localStorage.getItem('spice.refresh_token'));
  }

  same('six page loads all succeed', 6, visits);
  check('...without spending a refresh on each one', refreshCalls.count <= 1,
    `${refreshCalls.count} refresh call(s) for 6 navigations — the allowance is 30 per 10 minutes`);
}

// -----------------------------------------------------------------------
// The invoice page
//
// orders.html has always linked here; the page did not exist, so the link 404'd.
// -----------------------------------------------------------------------
console.log('\n-- Invoice --');

{
  const dom = makeDom(html());
  const api = await loadModule('api.js');

  const staff = await api.api.post('/auth/login',
    { identifier: '9000000099', password: 'AdminPass!2026' });
  api.storeTokens(staff.data.tokens);

  const orders = await api.api.get('/admin/orders', { per_page: 50 });
  const invoiced = (orders.data || []).find((o) => o.invoice_number);

  check('an invoiced order exists', Boolean(invoiced));

  if (invoiced) {
    // The page renders from this payload. Asserting the FIELD NAMES here is the
    // point: every storefront bug so far has been a name that did not match, and
    // those render as blanks or ₹0.00 rather than errors.
    const invoice = (await api.api.get(`/admin/orders/${invoiced.uuid}/invoice`)).data;

    check('the invoice payload has a seller', Boolean(invoice.seller && invoice.seller.legal_name));
    check('...a buyer', Boolean(invoice.buyer && invoice.buyer.name));
    check('...an invoice number', Boolean(invoice.invoice && invoice.invoice.number));
    check('...line items with descriptions',
      (invoice.lines || []).length > 0 && Boolean(invoice.lines[0].description));
    check('...a per-rate GST summary',
      (invoice.tax_summary || []).length > 0 && 'cgst_amount' in invoice.tax_summary[0]);
    check('...and totals that are not zero',
      Number(invoice.totals && invoice.totals.grand_total) > 0,
      JSON.stringify(invoice.totals));

    // The page itself must at least mount and produce something for a customer
    // who does not own this order — a 404, handled, not a crash.
    const invoiceDom = makeDom(html());
    invoiceDom.reconfigure({ url: `${API_URL}/shop/invoice.html?uuid=${invoiced.uuid}` });
    global.window = invoiceDom.window;
    global.document = invoiceDom.window.document;
    global.localStorage = invoiceDom.window.localStorage;

    let threw = null;

    try {
      await loadModule('page-invoice.js');
      await new Promise((r) => setTimeout(r, 800));
    } catch (error) {
      threw = error;
    }

    check('the invoice page handles a foreign order without crashing', threw === null,
      threw ? threw.message : '');
    check('...and shows something rather than a blank page',
      invoiceDom.window.document.querySelector('[data-page-root]').textContent.trim().length > 20);
  }
}

// -----------------------------------------------------------------------
// Adverts must actually be clickable
//
// Reported: adverts displayed but clicking did nothing. The public payload
// nests the link as `link: { type, value }`, while the admin endpoints use flat
// `link_type` / `link_value`. Reading the flat names gave undefined, so no
// anchor was rendered — and a banner with no link is a legitimate thing to
// render, so nothing failed or logged.
// -----------------------------------------------------------------------
console.log('\n-- Adverts --');

{
  const dom = makeDom(html());
  const api = await loadModule('api.js');

  const response = await api.api.get('/banners');
  const banners = response.data.banners || response.data || [];

  check('the banner endpoint answers', Array.isArray(banners));

  const linked = banners.find((banner) => banner.link && banner.link.type
    && banner.link.type !== 'none');

  if (!linked) {
    check('a linked advert exists to test the click path', true,
      'none configured; skipping the anchor assertions');
  } else {
    const bannerDom = makeDom('<!DOCTYPE html><html><body><div data-slot></div></body></html>');
    global.window = bannerDom.window;
    global.document = bannerDom.window.document;
    global.localStorage = bannerDom.window.localStorage;
    global.sessionStorage = bannerDom.window.sessionStorage;

    const banners_ = await loadModule('banners.js');
    await banners_.mountBanners(linked.placement || 'home_hero', '[data-slot]');

    const anchor = bannerDom.window.document.querySelector('.banner-link');

    check('a linked advert renders an anchor', anchor !== null,
      'without one, clicking does nothing at all');

    if (anchor) {
      const href = anchor.getAttribute('href');

      check('...with a real destination', Boolean(href) && href !== 'null', String(href));
      check('...and the picture inside it',
        anchor.querySelector('img') !== null || !linked.image_url,
        'a banner is mostly image; wrapping only the text leaves the clicked part dead');
    }

    check('...and a dismiss control',
      bannerDom.window.document.querySelector('[data-dismiss-banner]') !== null);
  }
}

// -----------------------------------------------------------------------
// Customers must be able to WRITE a review
//
// The moderation queue existed in the console and the API accepted submissions,
// but the shop offered no form at all — so the whole review system was
// write-only from the merchant's side and no customer could ever contribute.
// -----------------------------------------------------------------------
console.log('\n-- Writing a review --');

{
  const dom = makeDom(html());
  dom.reconfigure({ url: `${API_URL}/shop/product.html?slug=organic-turmeric-powder` });
  const api = await loadModule('api.js');
  const reviewForm = await loadModule('review-form.js');

  const host = dom.window.document.createElement('div');
  dom.window.document.body.appendChild(host);

  // Signed out: invited to sign in, not shown a box that will be refused.
  await reviewForm.mountReviewForm('organic-turmeric-powder', host);

  check('a signed-out visitor is invited to sign in',
    /sign in/i.test(host.textContent),
    host.textContent.trim().slice(0, 80));

  check('...and is not shown a form that would fail',
    host.querySelector('[data-review-form]') === null,
    'being refused after writing three paragraphs is worse than not being asked');

  // Signed in but has not bought it: told why, plainly.
  const mobile = `9${String(Math.floor(Math.random() * 1e9)).padStart(9, '0')}`;
  const registration = await api.api.post('/auth/register', {
    full_name: 'Review Gate',
    mobile,
    password: `Gate${Math.floor(Math.random() * 1e6)}`,
  });
  const verified = await api.api.post('/auth/register/verify', {
    mobile,
    otp: registration.data.verification.debug_otp,
    reference_token: registration.data.verification.reference_token,
  });
  api.storeTokens(verified.data.tokens);

  await reviewForm.mountReviewForm('organic-turmeric-powder', host);

  check('someone who has not bought it gets no form',
    host.querySelector('[data-review-form]') === null);
  // Matches the MEANING, not one sentence. An assertion pinned to exact prose
  // fails every time the copy improves, which trains people to ignore it.
  check('...and is told why, and what would change it',
    /received this can review/i.test(host.textContent)
      && /delivered/i.test(host.textContent),
    host.textContent.replace(/\s+/g, ' ').trim().slice(0, 110));

  // And the server refuses regardless of what the client does.
  let refused = false;

  try {
    await api.api.post('/products/organic-turmeric-powder/reviews',
      { rating: 5, body: 'Never bought this' });
  } catch (error) {
    refused = error.status >= 400;
  }

  check('the server refuses an unverified reviewer', refused,
    'the form is courtesy; this rule is the real guard');
}

// -----------------------------------------------------------------------
// Content pages
// -----------------------------------------------------------------------
console.log('\n-- Content pages --');

{
  const dom = makeDom(html());
  dom.reconfigure({ url: `${API_URL}/shop/page.html?slug=returns-and-refunds` });
  global.window = dom.window;

  await loadModule('page-page.js');

  const loaded = await waitFor(
    () => dom.window.document.querySelector('[data-page-root] h1') !== null,
    'the policy page to load',
  );
  check('a policy page renders', loaded);

  if (loaded) {
    const markup = dom.window.document.querySelector('[data-page-root]').innerHTML;
    check('...with paragraphs preserved', markup.includes('<p>'));
    check('...and no raw script execution path', !markup.includes('<script'),
      'CMS bodies are escaped, not rendered as HTML');
  }
}

{
  const dom = makeDom(html());
  dom.reconfigure({ url: `${API_URL}/shop/faq.html` });
  global.window = dom.window;

  await loadModule('page-faq.js');

  const loaded = await waitFor(
    () => dom.window.document.querySelectorAll('[data-page-root] .accordion-item').length > 0,
    'the FAQ to load',
  );
  check('the FAQ renders', loaded);
  check('...grouped into sections',
    dom.window.document.querySelectorAll('[data-page-root] section').length >= 2);
}

// -----------------------------------------------------------------------
// Every page module parses and runs without throwing
// -----------------------------------------------------------------------
console.log('\n-- All page modules --');

for (const name of ['page-catalog.js', 'page-product.js', 'page-cart.js', 'page-checkout.js',
                    'page-orders.js', 'page-account.js', 'page-support.js', 'page-faq.js',
                    'page-page.js']) {
  const dom = makeDom(`<!DOCTYPE html><html><body>
    <div data-chrome="header"></div>
    <main data-page-root></main>
    <div data-chrome="footer"></div>
    <form data-search-form><input id="search" name="q"></form>
    <select data-sort><option value=""></option></select>
    <h2 data-results-heading></h2>
    <div data-products></div>
    <nav data-pagination></nav>
    <div data-categories></div>
  </body></html>`);

  let threw = null;
  const originalError = console.error;
  console.error = () => {};

  try {
    await loadModule(name);
    await new Promise((r) => setTimeout(r, 300));
  } catch (error) {
    threw = error;
  } finally {
    console.error = originalError;
  }

  check(`${name} loads and runs`, threw === null, threw ? threw.message : '');
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
