/**
 * Admin console tests.
 *
 *   node web/test/test_console.mjs
 *
 * Same approach as the storefront tests: real modules, real DOM, live API.
 * Nothing mocked but the browser.
 *
 * The point is not to prove the console looks right — jsdom cannot tell you
 * that. It is to prove that every screen reads the field names the API actually
 * sends, and that the role gate works. A console that silently renders "—" for
 * every column because the API calls a field something else is worse than one
 * that fails loudly.
 */

import { JSDOM } from 'jsdom';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve } from 'node:path';

const nodeFetch = globalThis.fetch;
const NodeFormData = globalThis.FormData;
const NodeBlob = globalThis.Blob;
const HERE = dirname(fileURLToPath(import.meta.url));
const WEB_ROOT = resolve(HERE, '..');
const API_URL = process.env.CONSOLE_API || 'http://127.0.0.1:8081';

const ADMIN = {
  identifier: process.env.CONSOLE_ADMIN || '9000000099',
  password: process.env.CONSOLE_PASSWORD || 'AdminPass!2026',
};

let passed = 0;
let failed = 0;

function check(label, condition, detail = '') {
  if (condition) {
    passed += 1;
    console.log(`  PASS  ${label}`);
    return;
  }
  failed += 1;
  console.log(`  FAIL  ${label}${detail ? ` -> ${detail}` : ''}`);
}

function same(label, expected, actual) {
  check(label, expected === actual,
    `expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}

function makeDom(url = `${API_URL}/shop/admin/index.html`) {
  const dom = new JSDOM(`<!DOCTYPE html><html><body>
    <div data-console></div>
  </body></html>`, { url, pretendToBeVisual: true, runScripts: 'outside-only' });

  const wrapped = (input, init) => {
    const target = typeof input === 'string' && input.startsWith('/')
      ? `${API_URL}${input}`
      : input;
    return nodeFetch(target, init);
  };

  dom.window.fetch = wrapped;
  dom.window.SPICE_API_BASE = `${API_URL}/api/v1`;
  dom.window.localStorage.clear();

  global.window = dom.window;
  global.document = dom.window.document;
  global.localStorage = dom.window.localStorage;
  global.fetch = wrapped;
  global.URLSearchParams = dom.window.URLSearchParams;
  global.FormData = dom.window.FormData;

  return dom;
}

async function loadModule(relative) {
  const path = resolve(WEB_ROOT, relative);
  return import(`${pathToFileURL(path).href}?v=${Date.now()}${Math.random()}`);
}

async function waitFor(predicate, timeoutMs = 10000) {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    if (predicate()) return true;
    await new Promise((r) => setTimeout(r, 60));
  }

  return false;
}

/**
 * The staff refresh token, obtained ONCE for the whole run.
 *
 * Signing in per screen tripped the login throttle a dozen screens in, and the
 * suite then failed for a reason that had nothing to do with the console. The
 * throttle is correct; the harness was wrong to hammer it.
 */
let sharedRefreshToken = null;

async function signInAsAdmin(dom) {
  const apiModule = await loadModule('assets/js/api.js');

  if (sharedRefreshToken) {
    // Seed the token and let the client's own refresh turn it into an access
    // token — which exercises the refresh path on every screen for free.
    dom.window.localStorage.setItem('spice.refresh_token', sharedRefreshToken);
    await apiModule.bootstrapSession();
    sharedRefreshToken = dom.window.localStorage.getItem('spice.refresh_token');

    return { apiModule };
  }

  const response = await apiModule.api.post('/auth/login', ADMIN);
  apiModule.storeTokens(response.data.tokens);
  sharedRefreshToken = response.data.tokens.refresh_token;

  return { apiModule };
}

console.log('Admin console tests');
console.log(`API: ${API_URL}\n`);

// -----------------------------------------------------------------------
// The role gate
// -----------------------------------------------------------------------
console.log('-- Access --');

{
  const dom = makeDom();
  await loadModule('admin/assets/page-index.js');

  const showsSignIn = await waitFor(
    () => dom.window.document.querySelector('[data-signin-form]') !== null,
  );

  check('an anonymous visitor gets the sign-in screen', showsSignIn);
  check('...and no console chrome is rendered',
    dom.window.document.querySelector('.console-sidebar') === null,
    'the navigation should not appear before the role is known');
}

{
  // A CUSTOMER token must not open the console. Every endpoint would refuse
  // them anyway, but a wall of red errors is a poor way to say "wrong account".
  const dom = makeDom();
  const apiModule = await loadModule('assets/js/api.js');

  const mobile = `9${String(Math.floor(Math.random() * 1e9)).padStart(9, '0')}`;
  const registration = await apiModule.api.post('/auth/register', {
    full_name: 'Console Outsider',
    mobile,
    password: `Outsider${Math.floor(Math.random() * 1e6)}`,
  });

  const verified = await apiModule.api.post('/auth/register/verify', {
    mobile,
    otp: registration.data.verification.debug_otp,
    reference_token: registration.data.verification.reference_token,
  });

  dom.window.localStorage.setItem('spice.refresh_token', verified.data.tokens.refresh_token);

  await loadModule('admin/assets/page-index.js');

  const rejected = await waitFor(
    () => dom.window.document.querySelector('[data-signin-form]') !== null,
  );

  check('a customer account is turned away', rejected);

  const message = dom.window.document.body.textContent || '';
  check('...and told why', message.includes('not a staff account'),
    message.slice(0, 120));
}

// -----------------------------------------------------------------------
// Dashboard
// -----------------------------------------------------------------------
console.log('\n-- Dashboard --');

{
  const dom = makeDom();
  await signInAsAdmin(dom);
  await loadModule('admin/assets/page-index.js');

  const loaded = await waitFor(
    () => dom.window.document.querySelector('[data-page-root] h1') !== null,
  );

  check('the dashboard renders for staff', loaded);
  check('...with the navigation', dom.window.document.querySelector('.console-sidebar') !== null);

  const text = dom.window.document.querySelector('[data-page-root]').textContent;

  check('...showing today\'s orders', text.includes('Orders today'));
  check('...and revenue', text.includes('Revenue today'));
  check('...with the revenue definition stated', text.includes('not revenue'),
    'staff should know an unpaid order is not counted');

  const markup = dom.window.document.querySelector('[data-page-root]').innerHTML;
  check('...and no undefined values leaked into the page',
    !markup.includes('undefined') && !markup.includes('NaN'),
    'a field name that does not match the API shows up exactly like this');
}

// -----------------------------------------------------------------------
// Orders
// -----------------------------------------------------------------------
console.log('\n-- Orders --');

{
  const dom = makeDom(`${API_URL}/shop/admin/orders.html`);
  await signInAsAdmin(dom);
  await loadModule('admin/assets/page-orders.js');

  // NOT `.text-center` — that also matches the loading spinner, so the wait
  // returned immediately and every assertion below ran against a half-drawn
  // page. The condition has to describe the finished state, not any state.
  const loaded = await waitFor(
    () => {
      const list = dom.window.document.querySelector('[data-list]');
      if (!list) return false;
      if (list.querySelector('.spinner-border')) return false;
      return list.querySelector('table') !== null
        || list.textContent.includes('No orders');
    },
  );

  check('the order list renders', loaded);

  const markup = dom.window.document.querySelector('[data-page-root]').innerHTML;

  check('...with the operational filters', markup.includes('To pack') && markup.includes('To ship'));
  check('...and no undefined values', !markup.includes('undefined'), 'field names must match the API');

  const rows = dom.window.document.querySelectorAll('[data-list] tbody tr');

  if (rows.length > 0) {
    check('orders are listed', true);
    check('...each linking to its detail page',
      dom.window.document.querySelector('[data-list] a[href*="uuid="]') !== null);
    check('...showing a rupee total',
      dom.window.document.querySelector('[data-list] tbody').textContent.includes('₹'));
  } else {
    check('the empty state is shown when there are no orders',
      dom.window.document.querySelector('[data-list]').textContent.includes('No orders'));
  }
}

// The detail screen, and the BR-005 guard it displays.
{
  const dom = makeDom();
  const { apiModule } = await signInAsAdmin(dom);

  const list = await apiModule.api.get('/admin/orders', { per_page: 25 });
  const orders = list.data || [];
  const unpaid = orders.find((o) => o.payment_status === 'pending');
  const paid = orders.find((o) => o.payment_status === 'paid');

  if (unpaid) {
    const detailDom = makeDom(`${API_URL}/shop/admin/orders.html?uuid=${unpaid.uuid}`);
    await signInAsAdmin(detailDom);
    await loadModule('admin/assets/page-orders.js');

    const loaded = await waitFor(
      () => detailDom.window.document.querySelector('[data-actions]') !== null,
    );

    check('an unpaid order opens', loaded);

    const actions = detailDom.window.document.querySelector('[data-actions]').textContent;

    check('...and offers NO fulfilment actions',
      detailDom.window.document.querySelectorAll('[data-action]').length === 0,
      'BR-005: nothing progresses without a verified payment');
    check('...explaining why', actions.includes('paid for'), actions.slice(0, 100));
  } else {
    check('an unpaid order was available to check the BR-005 guard', false,
      'no pending order in the list; run the checkout smoke test first');
  }

  if (paid) {
    const detailDom = makeDom(`${API_URL}/shop/admin/orders.html?uuid=${paid.uuid}`);
    await signInAsAdmin(detailDom);
    await loadModule('admin/assets/page-orders.js');

    await waitFor(() => detailDom.window.document.querySelector('[data-actions]') !== null);

    const markup = detailDom.window.document.querySelector('[data-page-root]').innerHTML;

    check('a paid order shows its items', markup.includes('Items'));
    check('...its timeline', markup.includes('Timeline'));
    check('...the delivery address', markup.includes('Deliver to'));
    check('...and no undefined values', !markup.includes('undefined'));
  }
}

// -----------------------------------------------------------------------
// Reviews, support, products, promotions
// -----------------------------------------------------------------------
for (const [label, page, marker] of [
  ['Reviews', 'admin/assets/page-reviews.js', 'Reviews'],
  ['Support', 'admin/assets/page-support.js', 'Support'],
  ['Products', 'admin/assets/page-products.js', 'Products'],
  ['Promotions', 'admin/assets/page-promotions.js', 'Promotions'],
]) {
  console.log(`\n-- ${label} --`);

  const dom = makeDom(`${API_URL}/shop/admin/${page.split('page-')[1].replace('.js', '.html')}`);
  await signInAsAdmin(dom);
  await loadModule(page);

  const loaded = await waitFor(
    () => dom.window.document.querySelector('[data-page-root] h1') !== null,
  );

  check(`${label.toLowerCase()} renders`, loaded);

  if (!loaded) continue;

  // Give the asynchronous list its chance to settle.
  await new Promise((r) => setTimeout(r, 1200));

  const rootEl = dom.window.document.querySelector('[data-page-root]');
  const markup = rootEl.innerHTML;

  check(`...with the ${label.toLowerCase()} heading`, rootEl.textContent.includes(marker));
  check('...and no unresolved values', !markup.includes('undefined') && !markup.includes('NaN'),
    'a mismatched field name renders exactly like this');
  check('...and no API error banner', !markup.includes('alert-danger'),
    markup.includes('alert-danger')
      ? rootEl.querySelector('.alert-danger').textContent.trim().slice(0, 140)
      : '');
}

// -----------------------------------------------------------------------
// Creating a product end to end
//
// The gap this closes: before the editor existed, a merchant could publish and
// unpublish products but could not ADD one, so they could not list their own
// goods without calling the API by hand.
// -----------------------------------------------------------------------
console.log('\n-- Adding a product --');

{
  const dom = makeDom(`${API_URL}/shop/admin/products.html?new`);
  const { apiModule } = await signInAsAdmin(dom);
  await loadModule('admin/assets/page-products.js');

  const formShown = await waitFor(
    () => dom.window.document.querySelector('[data-product-form]') !== null,
  );

  check('the new-product form opens', formShown);

  if (formShown) {
    const form = dom.window.document.querySelector('[data-product-form]');

    check('...offering the real categories',
      form.querySelectorAll('#category_slug option').length > 1,
      'the category list is loaded from the API, not hardcoded');

    check('...with GST rates as a list, not a free number',
      form.querySelector('#gst_rate').tagName === 'SELECT',
      'picking the wrong rate is a tax problem, not a typo');

    check('...prompting for the FSSAI licence',
      form.textContent.includes('FSSAI'),
      'legally required for packaged food sold in India');

    check('...and for ingredients', form.textContent.includes('Ingredients'));

    check('...asking for the first pack size in the same form',
      form.querySelector('#v_selling_price') !== null,
      'the API refuses a product with no pack size, so both are created together');

    check('...stating that prices include GST', form.textContent.includes('INCLUDE GST'));

    // Fill it in and submit, exactly as a person would.
    const unique = Math.floor(Math.random() * 1e6);
    form.querySelector('#name').value = `Test Cardamom ${unique}`;
    form.querySelector('#product_code').value = `TSTC${unique}`;
    form.querySelector('#category_slug').selectedIndex = 1;
    form.querySelector('#short_description').value = 'Created by the console test.';
    form.querySelector('#v_variant_name').value = '100 g pouch';
    form.querySelector('#v_sku').value = `TSTC${unique}-100`;
    form.querySelector('#v_weight_grams').value = '100';
    form.querySelector('#v_mrp').value = '250';
    form.querySelector('#v_selling_price').value = '225';

    const submitted = new dom.window.Event('submit', { bubbles: true, cancelable: true });
    form.dispatchEvent(submitted);

    // The page navigates on success, which jsdom cannot follow, so the result is
    // confirmed against the API instead.
    await new Promise((r) => setTimeout(r, 1500));

    const listing = await apiModule.api.get('/admin/products', { q: `Test Cardamom ${unique}` });
    const created = (listing.data || []).find((p) => p.name === `Test Cardamom ${unique}`);

    check('the product was created', Boolean(created),
      `searched for "Test Cardamom ${unique}"`);

    if (created) {
      same('...as a draft, not on sale', 'draft', created.status);

      const detail = await apiModule.api.get(`/admin/products/${created.uuid}`);
      const variants = detail.data.product.variants || [];

      check('...with its first pack size', variants.length === 1, String(variants.length));

      if (variants.length === 1) {
        same('...at the weight given', 100, Number(variants[0].weight_grams));
        same('...and the selling price given', 225, Number(variants[0].selling_price));
      }

      // Add a pack size through the editor.
      const editDom = makeDom(`${API_URL}/shop/admin/products.html?edit=${created.uuid}`);
      await signInAsAdmin(editDom);
      await loadModule('admin/assets/page-products.js');

      const editorShown = await waitFor(
        () => editDom.window.document.querySelector('[data-variant-form]') !== null,
      );

      check('the editor opens for an existing product', editorShown);

      if (editorShown) {
        const panel = editDom.window.document.querySelector('[data-page-root]').textContent;

        check('...listing the pack size it already has', panel.includes('100 g pouch'));

        // A second pack size, added one at a time on the edit page.
        const variantForm = editDom.window.document.querySelector('[data-variant-form]');
        variantForm.querySelector('#variant_name').value = '500 g pouch';
        variantForm.querySelector('#sku').value = `TSTC${unique}-500`;
        variantForm.querySelector('#weight_grams').value = '500';
        variantForm.querySelector('#mrp').value = '1100';
        variantForm.querySelector('#selling_price').value = '999';

        variantForm.dispatchEvent(new editDom.window.Event('submit', { bubbles: true, cancelable: true }));
        await new Promise((r) => setTimeout(r, 1500));

        const updated = await apiModule.api.get(`/admin/products/${created.uuid}`);
        check('a second pack size can be added',
          (updated.data.product.variants || []).length === 2,
          String((updated.data.product.variants || []).length));

        // Publishing also needs a photograph. The console offers an upload
        // field; jsdom cannot drive a real file picker, so the image goes in
        // through the same endpoint the form posts to.
        const editorMarkup = editDom.window.document.querySelector('[data-page-root]').innerHTML;

        check('the editor offers a photograph upload',
          editorMarkup.includes('data-image-form'));
        check('...and explains that one is required before going on sale',
          editDom.window.document.querySelector('[data-page-root]').textContent
            .includes('photograph'));

        const pngBytes = Buffer.from(
          'iVBORw0KGgoAAAANSUhEUgAAAMgAAADIAQMAAACXljzdAAAAA1BMVEX///+nxBvIAAAAH0lEQVRoge3BAQ0A'
          + 'AADCoPdPbQ43oAAAAAAAAAAAAAAAAAAAgLcBLAAB6pUn9AAAAABJRU5ErkJggg==',
          'base64',
        );

        // Node's FormData and Blob, not jsdom's. `global.FormData` points at
        // jsdom's implementation, which refuses a Node Blob — and the request is
        // sent by Node's fetch anyway, so Node's types are the correct pair.
        const uploadBody = new NodeFormData();
        uploadBody.append('image', new NodeBlob([pngBytes], { type: 'image/png' }), 'probe.png');
        uploadBody.append('alt_text', 'Console test image');
        uploadBody.append('is_primary', '1');

        let uploaded = false;

        try {
          await apiModule.api.upload(`/admin/products/${created.uuid}/images`, uploadBody);
          uploaded = true;
        } catch (error) {
          check('the photograph uploaded', false,
            `${error.status}: ${JSON.stringify(error.errors)}`);
        }

        if (uploaded) check('the photograph uploaded', true);

        // Now it can go on sale, and must reach the public shop.
        await apiModule.api.post(`/admin/products/${created.uuid}/publish`, {});

        const shop = await apiModule.api.get('/products', { q: `Test Cardamom ${unique}` });
        const visible = (shop.data || []).some((p) => p.name === `Test Cardamom ${unique}`);

        check('once published it appears in the shop', visible,
          'the whole point of the editor is that a merchant can list their own goods');
      }
    }
  }
}

// -----------------------------------------------------------------------
// Every console module loads without throwing
// -----------------------------------------------------------------------
console.log('\n-- All console modules --');

for (const name of ['page-index.js', 'page-orders.js', 'page-support.js',
                    'page-reviews.js', 'page-products.js', 'page-promotions.js']) {
  const dom = makeDom();
  await signInAsAdmin(dom);

  let threw = null;
  const originalError = console.error;
  console.error = () => {};

  try {
    await loadModule(`admin/assets/${name}`);
    await new Promise((r) => setTimeout(r, 400));
  } catch (error) {
    threw = error;
  } finally {
    console.error = originalError;
  }

  check(`${name} loads and runs`, threw === null, threw ? threw.message : '');
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
